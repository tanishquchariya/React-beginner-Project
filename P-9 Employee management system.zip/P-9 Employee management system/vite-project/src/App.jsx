// App.jsx
import React from "react";
import { Routes, Route } from "react-router-dom";
import AdminLayout from "./Layout/AdminLayout";
import Attendance from "./pages/Attendance/Attendance";
import Dashboard from "./pages/Dashboard/Dashboard";
import Departments from "./pages/Departments/Departments";
import Employees from "./pages/Employees/Employees";
import Payroll from "./pages/Payroll/Payroll";
import Home from "./pages/Home";
const App = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />

        {/* This is called a Layout Route. */}
        <Route element={<AdminLayout />}>
        
         {/* Child routes */}
          <Route path="/attendance" element={<Attendance />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/departments" element={<Departments />} />
          <Route path="/employees" element={<Employees />} />
          <Route path="/payroll" element={<Payroll />} />
        </Route>
      </Routes>
    </>
  );
};

export default App;
